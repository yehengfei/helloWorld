package com.boyu.dandelion.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.boyu.dandelion.model.SysUserDetails;

@Service
public class SysUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SysUserDetails sysUserDetails = new SysUserDetails();
		return sysUserDetails;
	}

}

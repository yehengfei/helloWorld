package com.boyu;

public class Test {
    private ThreadLocal<A> localA = new ThreadLocal<>();

	public A getLocalA() {
		return localA.get();
	}

	public void setLocalA(A a) {
		this.localA.set(a);
	}
    
    public static void main(String[] args) {
		A a = new A();
		Test test = new Test();
		A testa = test.getLocalA();
		System.out.println("testa == " + testa);
		
		Test test2 = new Test();
		A test2a = test2.getLocalA();
		System.out.println("test2a == " + test2a);
		
		test.setLocalA(a);
		testa = test.getLocalA();
		System.out.println("testa == " + testa);
		test2.setLocalA(a);
		test2a = test2.getLocalA();
		System.out.println("test2a == " + test2a);
		
		a.setValue(1);
		System.out.println("testa == " + testa);
		System.out.println("test2a == " + test2a);
	}
    
}